See Documentation.html (or html/index.html) for the full documentation of the project.

The project source files are contained in the KinectGestureClassifier folder.

The project can be accessed and edited through the KinectGestureClassifier.sln file in Visual Studio.