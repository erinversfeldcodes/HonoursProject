var searchData=
[
  ['kinectgestureclassifier_2ecpp',['KinectGestureClassifier.cpp',['../_kinect_gesture_classifier_8cpp.html',1,'']]]
];
