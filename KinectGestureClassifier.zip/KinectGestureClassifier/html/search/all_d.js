var searchData=
[
  ['_7edataframe',['~DataFrame',['../class_h_a_n_d_g_r_1_1_data_frame.html#ae8baea1e0005895e8b18870befe21112',1,'HANDGR::DataFrame']]]
];
