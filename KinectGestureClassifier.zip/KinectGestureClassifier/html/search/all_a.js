var searchData=
[
  ['readimages',['readImages',['../namespace_h_a_n_d_g_r.html#a13ec6a07ab9bff641bbf72221426140d',1,'HANDGR']]],
  ['resizekeepaspectratio',['resizeKeepAspectRatio',['../class_h_a_n_d_g_r_1_1_data_frame.html#a24ea1d2f4395fc04fbbdb5f269597f8f',1,'HANDGR::DataFrame']]],
  ['resource_2eh',['resource.h',['../resource_8h.html',1,'']]]
];
