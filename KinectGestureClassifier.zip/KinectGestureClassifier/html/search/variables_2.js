var searchData=
[
  ['image',['image',['../struct_h_a_n_d_g_r_1_1_image_data.html#af1eb9cf42a2f859f0c0ffdcc1954cc39',1,'HANDGR::ImageData']]]
];
