var searchData=
[
  ['frame',['frame',['../class_h_a_n_d_g_r_1_1_data_frame.html#a79634072374e087a23440f662bb45268',1,'HANDGR::DataFrame']]]
];
