var searchData=
[
  ['loadframe',['loadFrame',['../class_h_a_n_d_g_r_1_1_data_frame.html#a0cf51d05ac5cc5f83c9632a6f06c648d',1,'HANDGR::DataFrame']]]
];
