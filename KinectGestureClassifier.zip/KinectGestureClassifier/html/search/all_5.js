var searchData=
[
  ['handgr',['HANDGR',['../namespace_h_a_n_d_g_r.html',1,'']]]
];
