var searchData=
[
  ['about_20kinect_20gesture_20classifier',['About Kinect Gesture Classifier',['../index.html',1,'']]]
];
