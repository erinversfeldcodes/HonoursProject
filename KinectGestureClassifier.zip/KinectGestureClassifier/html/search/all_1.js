var searchData=
[
  ['classname',['classname',['../struct_h_a_n_d_g_r_1_1_image_data.html#ab6b878d6301a7c8b05508b7257c49b17',1,'HANDGR::ImageData']]]
];
