#include "stdafx.h"
#include "DataFrame.h"

/** @file DataFrame.h */

using namespace std;
using namespace cv;
using namespace HANDGR;
using namespace boost::filesystem;

/**
 * DataFrame contructor.
*/
DataFrame::DataFrame() { }

/**
 * DataFrame decontructor. Releases frame variable.
*/
DataFrame::~DataFrame() { 
	frame.release(); 
}

/**
 * Finds the biggest contour and masks on image to obtain only biggest contour,
 * then crops immediately around the biggest contour.
 * @param none
*/
cv::Mat DataFrame::applyContourMask()
{
	cv::Mat contoured_img;
	Canny(frame, contoured_img, 100, 150);

	// find the contours
	vector<vector<Point>> contours;
	findContours(contoured_img, contours, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_SIMPLE);
	Mat mask = Mat::zeros(contoured_img.rows, contoured_img.cols, CV_8UC1);

	// fill the connected components found
	drawContours(mask, contours, -1, Scalar(255), CV_FILLED);

	// only draw largest connected component
	vector<double> areas(contours.size());
	int largest_contour_index = 0;
	int largest_area = 0;
	Rect bounding_rect;
	for (int i = 0; i< contours.size(); i++)
	{
		//  Find the area of contour
		double a = contourArea(contours[i], false);
		if (a > largest_area) {
			largest_area = a;
			// Store the index of largest contour
			largest_contour_index = i;
			// Find the bounding rectangle for biggest contour
			bounding_rect = boundingRect(contours[i]);
		}
	}

	cvtColor(mask, mask, CV_GRAY2BGR);
	drawContours(mask, contours, largest_contour_index, Scalar(255, 255, 255), CV_FILLED, 8);
	
	//FOR TESTING
	//imshow("contour", mask); 
	//waitKey(0);

	//find rectangle surrounding hand/roi and return this region
	rectangle(mask, bounding_rect, 0);
	Mat roi = mask(bounding_rect);
	
	return roi;
}

/*
 * Centers inputted image in a black image of width*height, while keeping aspect ratio of original inputted image.
 * @param input Mat image required to be resized 
 * @param width int width of desired resized image
 * @param height int height of desired resized image
 */
cv::Mat DataFrame::resizeKeepAspectRatio(const cv::Mat &input, int width, int height)
{
	cv::Mat resized;

	double h1 = width * (input.rows/(double)input.cols);
	double w2 = height * (input.cols/(double)input.rows);
	if (h1 <= height) {
		cv::resize(input, resized, cv::Size(width, h1));
	}
	else {
		cv::resize(input, resized, cv::Size(w2, height));
	}

	int top = (height - resized.rows) / 2;
	int down = (height - resized.rows + 1) / 2;
	int left = (width - resized.cols) / 2;
	int right = (width - resized.cols + 1) / 2;

	cv::copyMakeBorder(resized, resized, top, down, left, right, cv::BORDER_CONSTANT, Scalar(0));

	//FOR TESTING
	//imshow("resized", resized);

	cvtColor(resized, resized, CV_RGB2GRAY);

	//FOR TESTING
	//imshow("greyscale", resized);
	//waitKey(0);

	return resized;
}


/**
* Opens image given a filename. If read image is empty, then false returned and image is invalid.
* Else, image is valid. 
* @param filename string specifying direct path (including filename) to frame
*/
bool HANDGR::DataFrame::loadFrame(std::string filename)
{
	frame = imread(filename);
	cvtColor(frame, frame, CV_BGR2GRAY);
	if (countNonZero(frame) > 0 || !frame.empty())
	{
		//FOR TESTING
		//imshow("initial frame", frame);
		//waitKey(0);
		return true;
	}
	else
		return false;
}


/**
* Gets all sub-directories in given directory.
* @param directory string specifying given path to search for sub-directories
* @param filelist (output) vector of strings that found sub-directories are added to
*/
void HANDGR::getSubDirectoriesInDirectory(const std::string& directory, std::vector<std::string>& filelist)
{
	path root(directory);
	directory_iterator it_end;

	for (directory_iterator it(root); it != it_end; ++it)
	{
		if (is_regular_file(it->path()))
		{
			//do nothing if regular file
		}
		if (is_directory(it->path()))
		{
			//add to filelist if directory found
			filelist.push_back(it->path().string());
		}
	}
}

/**
 * Finds the first valid frame of a given gesture folder. Returns true if valid frame is found, else false.
 * Valid frame is considered as both non-empty and containing a contour that is at least 30x30 in pixel size.
 * @param valid (output) int to count number of valid gestures 
 * @param invalid (output) int to count number of invalid gestures
 * @param directory string specifying gesture directory
 * @param validfile (output) string specifying full path to valid gesture frame found
 * @param validframe (output) Mat containing valid frame, cropped and resized <feature vector extraction completed here>
*/
bool HANDGR::getFirstValidFrame(int& valid, int& invalid, const std::string& directory, std::string& validfile, cv::Mat& validframe)
{
	//assume directory of a gesture performance
	path root(directory);
	directory_iterator it_end;
	bool found_valid;

	for (directory_iterator it(root); it != it_end; ++it)
	{
		if (is_regular_file(it->path()))
		{
			std::string filename = it->path().string();
			DataFrame img;
			cout << ">>> NEXT FRAME: " << filename << endl;
			if (img.loadFrame(filename)) {
				//std::cout << "Reading gesture " << filename << "..." << std::endl;
				std::string classname = getClassName(filename);
				cv::Mat frame = img.applyContourMask();
				//cout << frame.rows << " " << frame.cols << endl;
				if ((frame.rows < 30) || (frame.cols < 30)) {
					cout << "Invalid frame [" + filename + "]" << endl;
				}
				else {
					++valid;
					//std::cout << "VALID FRAME FOUND: " << filename << "..." << std::endl;
					validfile = filename;
					validframe = DataFrame::resizeKeepAspectRatio(frame, 30, 30);
					return true;
				}
			}
		}
	}
	cout << "Invalid gesture [" + directory + "]" << endl;
	++invalid;
	return false;
}

/**
* Get classname of a gesture given the full path to the gesture.
* @param filename string specifying full path to gesture 
*/
string HANDGR::getClassName(std::string filename)
{
	std::vector<std::string> results;
	boost::split(results, filename, [](char c) {return c == '\\'; });

	//get first character (letter) of gesture folder
	return results[results.size() - 1].substr(0, 1);
}

/**
* Turns a classname into a binary number (in a Mat format, for ml purposes), 
* based on number of unique classes. 
* @param classes set of strings labelling all unique classes
* @param classname string of class which binary is required for
*/
cv::Mat HANDGR::getClassCode(const std::set<std::string>& classes, const std::string& classname) {
	cv::Mat code = cv::Mat::zeros(cv::Size((int)classes.size(), 1), CV_32F);
	int index = 0;
	for (auto it = classes.begin(); it != classes.end(); ++it)
	{
		if (*it == classname) break;
		++index;
	}
	code.at<float>(index) = 1;
	return code;
};

/**
 * Fully extracts a feature vector (cropped and resized) from a given frame (assuming valid).
 * @param filename string specifying file pointing to frame
 */
cv::Mat HANDGR::getImage(std::string filename)
{
	DataFrame frame;
	cv::Mat crop = frame.applyContourMask();
	cv::Mat resized = DataFrame::resizeKeepAspectRatio(crop, 30, 30);
	return resized;
}

/**
* Find an index of a class given unique set of classes.
* @param classes all unique class names
* @param classname string of classname that index is required for
*/
int HANDGR::getClassId(const std::set<std::string>& classes, const std::string& classname)
{
	int index = 0;
	for (auto it = classes.begin(); it != classes.end(); ++it)
	{
		if (*it == classname) break;
		++index;
	}
	return index;
}

/**
* Receives a column matrix containing the probabilities associated to
* each class and returns the id of column which contains the highest
* probability (for ANN).
* @param predictions probabilities of predictions from an ANN, in the form of Mat
*/
int HANDGR::getPredictedClass(const cv::Mat& predictions)
{
	float maxPrediction = predictions.at<float>(0);
	float maxPredictionIndex = 0;
	const float* ptrPredictions = predictions.ptr<float>(0);
	for (int i = 0; i < predictions.cols; i++)
	{
		float prediction = *ptrPredictions++;
		if (prediction > maxPrediction)
		{
			maxPrediction = prediction;
			maxPredictionIndex = i;
		}
	}
	return maxPredictionIndex;
}

/**
* Get a trained multi-layer perceptron neural network.
* @param trainSamples Mat containing training data where each row is a data sample
* @param trainResponses Mat containing respective labels for training data
* @param layerSizes vector of integers specifying sizes of layers of network
*/
cv::Ptr<cv::ml::ANN_MLP> HANDGR::getTrainedNeuralNetwork(const cv::Mat& trainSamples, const cv::Mat& trainResponses, std::vector<int> & layerSizes)
{
	cv::Ptr<cv::ml::ANN_MLP> mlp = cv::ml::ANN_MLP::create();
	mlp->setTermCriteria(TermCriteria(TermCriteria::MAX_ITER + TermCriteria::EPS, 1000, 0.0001));
	mlp->setLayerSizes(layerSizes);
	mlp->setActivationFunction(cv::ml::ANN_MLP::SIGMOID_SYM);
	mlp->train(trainSamples, cv::ml::ROW_SAMPLE, trainResponses);
	return mlp;
}

/**
* Get a trained Polynomial-Kernel SVM.
* @param trainSamples Mat containing training data where each row is a data sample
* @param trainResponses Mat containing respective labels for training data
* @param degree int specifying degree to set for kernel
* @param c float specifying c value to be set 
*/
cv::Ptr<cv::ml::SVM> HANDGR::getTrainedPolySVM(const cv::Mat& trainSamples, const cv::Mat& trainResponses, const int degree, const float c)
{
	Ptr<ml::SVM> svm = ml::SVM::create();
	svm->setType(ml::SVM::C_SVC);
	svm->setKernel(ml::SVM::POLY);
	svm->setDegree(degree);
	svm->setC(c);
	svm->setTermCriteria(TermCriteria(TermCriteria::MAX_ITER + TermCriteria::EPS, 1000, 0.0001));
	svm->train(trainSamples, ml::ROW_SAMPLE, trainResponses);
	return svm;
}

/**
* Get a trained RBF-Kernel SVM.
* @param trainSamples Mat containing training data where each row is a data sample
* @param trainResponses Mat containing respective labels for training data
* @param gamma double specifying gamma value to be set
* @param c float specifying c value to be set
*/
cv::Ptr<cv::ml::SVM> HANDGR::getTrainedRBFSVM(const cv::Mat& trainSamples, const cv::Mat& trainResponses, const double gamma, const float c)
{
	Ptr<ml::SVM> svm = ml::SVM::create();
	svm->setType(ml::SVM::C_SVC);
	svm->setKernel(ml::SVM::RBF);
	svm->setGamma(gamma);
	svm->setC(c);
	svm->setTermCriteria(TermCriteria(TermCriteria::MAX_ITER + TermCriteria::EPS, 1000, 0.0001));
	svm->train(trainSamples, ml::ROW_SAMPLE, trainResponses);
	return svm;
}

/**
* Get a trained RBF-Kernel SVM, automatically finding best parameters according to a grid-search.
* @param trainSamples Mat containing training data where each row is a data sample
* @param trainResponses Mat containing respective labels for training data
*/
cv::Ptr<cv::ml::SVM> HANDGR::getAutoTrainedRBFSVM(const cv::Mat& trainSamples, const cv::Mat& trainResponses)
{
	Ptr<ml::SVM> svm = ml::SVM::create();
	svm->setType(ml::SVM::C_SVC);
	svm->setKernel(ml::SVM::RBF);
	svm->setTermCriteria(TermCriteria(TermCriteria::MAX_ITER + TermCriteria::EPS, 1000, 0.0001));
	ml::ParamGrid nogrid = ml::ParamGrid::ParamGrid(0, 0, 0);
	Ptr<ml::TrainData> td = ml::TrainData::create(trainSamples, ml::ROW_SAMPLE, trainResponses);
	svm->trainAuto(td, 10, ml::SVM::getDefaultGrid(ml::SVM::C), ml::SVM::getDefaultGrid(ml::SVM::GAMMA), nogrid, nogrid, nogrid, nogrid);
	return svm;
}

/**
* Get a trained Linear-Kernel SVM.
* @param trainSamples Mat containing training data where each row is a data sample
* @param trainResponses Mat containing respective labels for training data
* @param c float specifying c value to be set
*/
cv::Ptr<cv::ml::SVM> HANDGR::getTrainedLinearSVM(const cv::Mat& trainSamples, const cv::Mat& trainResponses, const float c)
{
	Ptr<ml::SVM> svm = ml::SVM::create();
	svm->setType(ml::SVM::C_SVC);
	svm->setKernel(ml::SVM::LINEAR);
	svm->setC(c);
	svm->setTermCriteria(TermCriteria(TermCriteria::MAX_ITER + TermCriteria::EPS, 1000, 0.0001));
	svm->train(trainSamples, ml::ROW_SAMPLE, trainResponses);
	return svm;
}

/**
* Uses an MLP to predict test data and then form a confusion matrix.
* @param mlp trained network variable
* @param testSamples Mat containing row samples of test data
* @param testOutputExpected vector containing actual labels of test data (according to indices of class labels)
*/
std::vector<std::vector<int>> HANDGR::getMLPConfusionMatrix(cv::Ptr<cv::ml::ANN_MLP> mlp, const cv::Mat& testSamples, const std::vector<int>& testOutputExpected)
{
	cv::Mat testOutput;
	mlp->predict(testSamples, testOutput);
	std::vector<std::vector<int>> confusionMatrix(26, std::vector<int>(26));
	for (int i = 0; i < testOutput.rows; i++)
	{
		int predictedClass = getPredictedClass(testOutput.row(i));
		int expectedClass = testOutputExpected.at(i);
		confusionMatrix[expectedClass][predictedClass]++;
	}
	return confusionMatrix;
}

/**
* Uses an SVM to predict test data and then form a confusion matrix.
* @param svm trained svm variable
* @param testSamples Mat containing row samples of test data
* @param testOutputExpected vector containing actual labels of test data (according to indices of class labels)
*/
std::vector<std::vector<int>> HANDGR::getSVMConfusionMatrix(cv::Ptr<cv::ml::SVM> svm, const cv::Mat& testSamples, const std::vector<int>& testOutputExpected)
{
	cv::Mat testOutput;
	svm->predict(testSamples, testOutput);
	std::vector<std::vector<int>> confusionMatrix(26, std::vector<int>(26));
	for (int i = 0; i < testOutput.rows; i++)
	{
		int predictedClass = testOutput.row(i).at<float>(0);
		int expectedClass = testOutputExpected.at(i);
		confusionMatrix[expectedClass][predictedClass]++;
	}
	return confusionMatrix;
}

/**
* Add one matrix to another, using standard matrix addition.
* @param out (output) matrix to be added to
* @param vec matrix to be added to out variable
*/
void HANDGR::addMatrix(std::vector<std::vector<int>> & out, std::vector<std::vector<int>> & vec)
{
	for (int i = 0; i < out.size(); ++i)
	{
		for (int j = 0; j < out[i].size(); ++j)
			out[i][j] += vec[i][j];
	}
}

/**
* Get a trained kNN.
* @param trainSamples Mat containing training data where each row is a data sample
* @param trainResponses Mat containing respective labels for training data
* @param k int specifying k value to be set
*/
cv::Ptr<cv::ml::KNearest> HANDGR::getTrainedKNN(const cv::Mat & trainSamples, const cv::Mat & trainResponses, const int k)
{
	cv::Ptr<cv::ml::KNearest> knn = cv::ml::KNearest::create();
	knn->setDefaultK(k);
	knn->setIsClassifier(true);
	knn->train(trainSamples, cv::ml::ROW_SAMPLE, trainResponses);
	return knn;
}

/**
* Uses a KNN to predict test data and then form a confusion matrix.
* @param knn trained knn classifier variable
* @param testSamples Mat containing row samples of test data
* @param testOutputExpected vector containing actual labels of test data (according to indices of class labels)
*/
std::vector<std::vector<int>> HANDGR::getKNNConfusionMatrix(cv::Ptr<cv::ml::KNearest> knn, const cv::Mat & testSamples, const std::vector<int>& testOutputExpected)
{
	cv::Mat testOutput;
	knn->findNearest(testSamples, knn->getDefaultK(), testOutput);
	std::vector<std::vector<int>> confusionMatrix(26, std::vector<int>(26));
	for (int i = 0; i < testOutput.rows; i++)
	{
		int predictedClass = testOutput.row(i).at<float>(0);
		int expectedClass = testOutputExpected.at(i);
		confusionMatrix[expectedClass][predictedClass]++;
	}
	return confusionMatrix;
}

/**
* Uses a voting classifier to predict test data and then form a confusion matrix.
* @param svmLin trained svm (with linear kernel) variable
* @param svmPoly trained svm (with polynomial kernel) variable (selected as preferred classifier)
* @param knn trained knn variable
* @param testSamples Mat containing row samples of test data
* @param testOutputExpected vector containing actual labels of test data (according to indices of class labels)
* @param votingHard determine voting type: true is hard voting, false is soft voting (future work)
*/
std::vector<std::vector<int>> HANDGR::getVotingClassifierConfusionMatrix(cv::Ptr<cv::ml::SVM> & svmLin, cv::Ptr<cv::ml::SVM> & svmPoly, cv::Ptr<cv::ml::KNearest> & knn, const cv::Mat & testSamples, const std::vector<int>& testOutputExpected, const bool votingHard)
{
	cout << "Predicting on Linear Kernel SVM..." << endl;
	Mat svmLinTestOutput;
	svmLin->predict(testSamples, svmLinTestOutput);
	cout << "---> Prediction complete." << endl;

	cout << "Predicting on Polynomial Kernel SVM..." << endl;
	Mat svmPolyTestOutput;
	svmPoly->predict(testSamples, svmPolyTestOutput);
	cout << "---> Prediction complete." << endl;

	cout << "Predicting on KNN..." << endl;
	Mat knnTestOutput;
	knn->findNearest(testSamples, 10, knnTestOutput);
	cout << "---> Prediction complete." << endl;

	cout << "Predicting using voting between 3 classifiers..." << endl;
	vector<vector<int>> confusionMatrix(26, std::vector<int>(26));
	int counter = 0;
	cout << "mlp test output rows " << svmLinTestOutput.rows << endl;
	for (int i = 0; i < svmLinTestOutput.rows; ++i) {
		int expectedClass = testOutputExpected.at(i);

		int svmPolyPredictedClass = svmPolyTestOutput.row(i).at<float>(0);
		int svmLinPredictedClass = svmLinTestOutput.row(i).at<float>(0);
		int knnPredictedClass = knnTestOutput.row(i).at<float>(0);

		map<int, int> predictions;
		predictions[svmPolyPredictedClass] = 1;
		if (predictions.find(svmLinPredictedClass) != predictions.end())
			predictions[svmLinPredictedClass]++;
		else
			predictions[svmLinPredictedClass] = 1;
		if (predictions.find(knnPredictedClass) != predictions.end())
			predictions[knnPredictedClass]++;
		else
			predictions[knnPredictedClass] = 1;

		if (predictions.size() == 3) // no majority, choose SVM
		{
			confusionMatrix[expectedClass][svmPolyPredictedClass]++;
			counter++;
		}
		else {
			for (map<int, int>::iterator it = predictions.begin(); it != predictions.end(); ++it) {
					if (it->second == 2 || it->second == 3) {
						confusionMatrix[expectedClass][it->first]++;
						counter++;
						break;
					}
			}
		}
	}
	cout << "count " << counter << endl;
	cout << "---> Prediction completed." << endl << endl;

	return confusionMatrix;
}

/**
* Get a string of the confusion matrix.
* @param confusionMatrix given confusion matrix to convert to string form
* @param classes set of strings of class labels
*/
string HANDGR::getConfusionMatrixString(const std::vector<std::vector<int>>& confusionMatrix, const std::set<std::string>& classes)
{
	stringstream ss;
	ss << "  ";

	for (auto it = classes.begin(); it != classes.end(); ++it)
	{
		ss << *it << " ";
	}
	ss << std::endl;

	auto it = classes.begin();
	for (size_t i = 0; i < confusionMatrix.size(); i++)
	{
		ss << *it << " ";
		for (size_t j = 0; j < confusionMatrix[i].size(); j++)
		{
			ss << confusionMatrix[i][j] << " ";
		}
		ss << std::endl;
		++it;
	}
	return ss.str();
}

/**
* Get the accuracy for a model (i.e., percentage of correctly predicted test samples).
* @param confusionMatrix given matrix to obtain accuracy from
*/
float HANDGR::getAccuracy(const std::vector<std::vector<int>>& confusionMatrix)
{
	int hits = 0;
	int total = 0;
	for (size_t i = 0; i < confusionMatrix.size(); i++)
	{
		for (size_t j = 0; j < confusionMatrix.at(i).size(); j++)
		{
			if (i == j) hits += confusionMatrix.at(i).at(j);
			total += confusionMatrix.at(i).at(j);
		}
	}
	return hits / (float)total;
}


/**
* Read in images given list of file names, and returns all feature vector frames for valid gestures.
* @param valid number of valid gestures
* @param invalid number of invalid gestures
* @param begin start of list of files
* @param end end of list of files
* @param callback lambda function which further processes each found valid frame to find feature vector and store as necessary
*/
void HANDGR::readImages(int & valid, int & invalid, std::vector<std::string>::const_iterator begin, std::vector<std::string>::const_iterator end, std::function<void(const std::string&, const cv::Mat&)> callback)
{
	for (auto it = begin; it != end; ++it)
	{
		string gesture_folder = *it;
		string temp;
		cv::Mat frame;
		string classname = getClassName(gesture_folder);
		if (getFirstValidFrame(valid, invalid, gesture_folder, temp, frame))
			callback(classname, frame);
	}
}