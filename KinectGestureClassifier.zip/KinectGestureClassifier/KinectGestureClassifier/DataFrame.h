#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <set>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/objdetect/objdetect.hpp>
#include <boost/filesystem.hpp>
#include <boost/filesystem/operations.hpp>
#include <boost/filesystem/path.hpp>
#include <boost/progress.hpp>
#include <boost/algorithm/string.hpp>
#include <opencv2/ml/ml.hpp>

/** @file DataFrame.cpp */

/**
* HANDGR namespace
*/
namespace HANDGR {


	/**
	* Handles a single image frame and processing before feeding into classifier.
	*/
	class DataFrame {
		public:
			cv::Mat frame;
			DataFrame();
			~DataFrame();

			cv::Mat applyContourMask();
			static cv::Mat resizeKeepAspectRatio(const cv::Mat & input, int width, int height);
			bool loadFrame(std::string filename);
	};

	/**
	* To associate a frame with a classname (gesture with a letter label).
	*/
	struct ImageData
	{
		std::string classname;
		cv::Mat image;
	};


	/* Methods to deal with reading images and files */
	void readImages(int & valid, int & invalid, std::vector<std::string>::const_iterator begin, std::vector<std::string>::const_iterator end, std::function<void(const std::string&, const cv::Mat&)> callback);
	void getSubDirectoriesInDirectory(const std::string& directory, std::vector<std::string>& filelist);
	cv::Mat getImage(std::string filename);	
    bool getFirstValidFrame(int& valid, int& invalid, const std::string& directory, std::string& validfile, cv::Mat& validframe);
	
	/* Methods for managing classes of classified frames */
	std::string getClassName(std::string filename);
	cv::Mat getClassCode(const std::set<std::string>& classes, const std::string& classname);
	int getClassId(const std::set<std::string>& classes, const std::string& classname);
	int getPredictedClass(const cv::Mat& predictions);

	/* Train and test Artificial Neural Network */
	cv::Ptr<cv::ml::ANN_MLP> getTrainedNeuralNetwork(const cv::Mat& trainSamples, const cv::Mat& trainResponses, std::vector<int> & layerSizes);
	cv::Ptr<cv::ml::SVM> getTrainedLinearSVM(const cv::Mat & trainSamples, const cv::Mat & trainResponses, const float c);
	std::vector<std::vector<int>> getMLPConfusionMatrix(cv::Ptr<cv::ml::ANN_MLP> mlp, const cv::Mat& testSamples, const std::vector<int>& testOutputExpected);

	/* Train and test Support Vector Machine */
	cv::Ptr<cv::ml::SVM> getTrainedPolySVM(const cv::Mat& trainSamples, const cv::Mat& trainResponses, const int degree, const float c);
	cv::Ptr<cv::ml::SVM> getTrainedRBFSVM(const cv::Mat & trainSamples, const cv::Mat & trainResponses, const double gamma, const float c);
	cv::Ptr<cv::ml::SVM> getAutoTrainedRBFSVM(const cv::Mat & trainSamples, const cv::Mat & trainResponses);
	std::vector<std::vector<int>> getSVMConfusionMatrix(cv::Ptr<cv::ml::SVM> svm, const cv::Mat& testSamples, const std::vector<int>& testOutputExpected);

	/* Train and test k-Nearest Neighbour Classifier */
	cv::Ptr<cv::ml::KNearest> getTrainedKNN(const cv::Mat& trainSamples, const cv::Mat& trainResponses, const int k);
	std::vector<std::vector<int>> getKNNConfusionMatrix(cv::Ptr<cv::ml::KNearest> knn, const cv::Mat& testSamples, const std::vector<int>& testOutputExpected);

	/* Train and test Voting Classifier */
	/* Ensemble classifier */
	std::vector<std::vector<int>> getVotingClassifierConfusionMatrix(cv::Ptr<cv::ml::SVM>& svmLin, cv::Ptr<cv::ml::SVM>& svmPoly, cv::Ptr<cv::ml::KNearest>& knn, const cv::Mat & testSamples, const std::vector<int>& testOutputExpected, const bool votingHard);

	/* Confusion matrix */
	std::string getConfusionMatrixString(const std::vector<std::vector<int>>& confusionMatrix, const std::set<std::string>& classes);
	void addMatrix(std::vector<std::vector<int>> & out, std::vector<std::vector<int>> & vec);
	float getAccuracy(const std::vector<std::vector<int>>& confusionMatrix);

}
