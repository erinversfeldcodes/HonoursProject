
/*! \mainpage About Kinect Gesture Classifier
*
* \section intro_sec This project explores the use of specific classifiers, namely MLPs, SVMs and kNNs, from the OpenCV Machine Learning namespace. This is done together with South African Sign Language Alphabet data obtained from the Microsoft Kinect, in the form of hand contour frames. 
* 
* This program was coded by Shaheel Kooverjee. It is strongly based on an OpenCV tutorial found at https://picoledelimao.github.io/blog/2016/01/31/is-it-a-cat-or-dog-a-neural-network-application-in-opencv/.
*
*
* \section install_sec Installation
*
* This project is a Visual Studio project, and has been specifically coded in Microsoft Visual Studio Community 2015.
* The project does require OpenCV 3.2.0 to be installed: http://opencv.org/opencv-3-2.html.
* Additionally, C++ Boost libraries are needed: http://www.boost.org/users/history/version_1_64_0.html.
*
* \section Running_sec Running
*
* To run this program, a string path argument must be specified, either in the command line, or in the project debugging arguments under the Visual Studio project properties. This path must be the full path to the directory of the dataset to be used with the program, and the directory must have participant sub-folders, each with 'Kinect' sub-folders containing the respective gesture folders of the participant. This format can be observed in the accompanying dataset.
*
*/

#include "stdafx.h"
#include "DataFrame.h"
#include <windows.h>

using namespace cv;
using namespace std;
using namespace HANDGR;
using namespace boost::filesystem;

/** Method to assist with cross-validation, for all classifiers except MLP.
  * Given a specifically chosen test participant, data is separated 
  * into required information for training and testing respectively.
  * @param gestureData vector<vector<ImageData*>> containing all data from a given dataset, split according to participants
  * @param testParticipant int index of gestureData, to indicate participant to remove from dataset for testing
  * @param trainSamples (output) Mat for all training data samples
  * @param trainLabels (output) Mat for all training labels for respective training data 
  * @param testSamples (output) Mat for all testing data samples
  * @param expectedTestOutput (output) vector<int> for all actual test labels for respective testing data
  * @param classes set<string> all unique class labels
  */
void getTrainAndTestData(const vector<vector<ImageData*>> & gestureData, const int testParticipant,
	Mat & trainSamples, Mat & trainLabels, Mat & testSamples,
	vector<int> & expectedTestOutput, const set<string> & classes) 
{
	//clear all output variables
	trainSamples = Mat();
	trainLabels = Mat();
	testSamples = Mat();
	expectedTestOutput.clear();

	for (int participant = 0; participant < gestureData.size(); ++participant) {
		// for testing participant data
		if (participant == testParticipant) {
			for (int gesture = 0; gesture < gestureData[participant].size(); ++gesture)
			{
				testSamples.push_back(gestureData[participant][gesture]->image);
				expectedTestOutput.push_back(getClassId(classes, gestureData[participant][gesture]->classname));
			}
		}
		// for training participant data
		else {
			for (int gesture = 0; gesture < gestureData[participant].size(); ++gesture)
			{
				trainSamples.push_back(gestureData[participant][gesture]->image);
				trainLabels.push_back(getClassId(classes, gestureData[participant][gesture]->classname));
			}
		}

	}

	trainSamples.convertTo(trainSamples, CV_32F);
	testSamples.convertTo(testSamples, CV_32F);

}

/** Method to assist with cross-validation, specifically for MLP classifier.
* Given a specifically chosen test participant, data is separated
* into required information for training and testing respectively.
* @param gestureData vector<vector<ImageData*>> containing all data from a given dataset, split according to participants
* @param testParticipant int index of gestureData, to indicate participant to remove from dataset for testing
* @param trainSamples (output) Mat for all training data samples
* @param trainLabelsMLP (output) Mat for all training labels for respective training data, in format required by MLP
* @param testSamples (output) Mat for all testing data samples
* @param expectedTestOutput (output) vector<int> for all actual test labels for respective testing data
* @param classes set<string> all unique class labels
*/
void getTrainAndTestDataMLP(const vector<vector<ImageData*>> & gestureData, const int testParticipant,
	Mat & trainSamples, Mat & trainLabelsMLP, Mat & testSamples,
	vector<int> & expectedTestOutput, const set<string> & classes)
{
	//clear all output variables
	trainSamples = Mat();
	trainLabelsMLP = Mat();
	testSamples = Mat();
	expectedTestOutput.clear();

	for (int participant = 0; participant < gestureData.size(); ++participant) {
		// for testing participant data
		if (participant == testParticipant) {
			for (int gesture = 0; gesture < gestureData[participant].size(); ++gesture)
			{
				testSamples.push_back(gestureData[participant][gesture]->image);
				expectedTestOutput.push_back(getClassId(classes, gestureData[participant][gesture]->classname));
			}
		}
		// for training participant data
		else {
			for (int gesture = 0; gesture < gestureData[participant].size(); ++gesture)
			{
				trainSamples.push_back(gestureData[participant][gesture]->image);
				trainLabelsMLP.push_back(getClassCode(classes, gestureData[participant][gesture]->classname));
			}
		}

	}

	trainSamples.convertTo(trainSamples, CV_32F);
	testSamples.convertTo(testSamples, CV_32F);

}

/** Method to assist with cross-validation, for ALL classifiers (including MLP).
* Given a specifically chosen test participant, data is separated
* into required information for training and testing respectively.
* @param gestureData vector<vector<ImageData*>> containing all data from a given dataset, split according to participants
* @param testParticipant int index of gestureData, to indicate participant to remove from dataset for testing
* @param trainSamples (output) Mat for all training data samples
* @param trainLabels (output) Mat for all training labels for respective training data
* @param trainLabelsMLP (output) Mat for all training labels for respective training data, in format required by MLP
* @param testSamples (output) Mat for all testing data samples
* @param expectedTestOutput (output) vector<int> for all actual test labels for respective testing data
* @param classes set<string> all unique class labels
*/
void getAllTrainAndTestData(const vector<vector<ImageData*>> & gestureData, const int testParticipant,
	Mat & trainSamples, Mat & trainLabels, Mat & trainLabelsMLP, Mat & testSamples,
	vector<int> & expectedTestOutput, const set<string> & classes)
{
	//clear all output variables
	trainSamples = Mat();
	trainLabels = Mat();
	trainLabelsMLP = Mat();
	testSamples = Mat();
	expectedTestOutput.clear();

	for (int participant = 0; participant < gestureData.size(); ++participant) {

		if (participant == testParticipant) {
			for (int gesture = 0; gesture < gestureData[participant].size(); ++gesture)
			{
				testSamples.push_back(gestureData[participant][gesture]->image);
				expectedTestOutput.push_back(getClassId(classes, gestureData[participant][gesture]->classname));
			}
		}

		else {
			for (int gesture = 0; gesture < gestureData[participant].size(); ++gesture)
			{
				trainSamples.push_back(gestureData[participant][gesture]->image);
				trainLabelsMLP.push_back(getClassCode(classes, gestureData[participant][gesture]->classname));
				trainLabels.push_back(getClassId(classes, gestureData[participant][gesture]->classname));
			}
		}

	}

	trainSamples.convertTo(trainSamples, CV_32F);
	testSamples.convertTo(testSamples, CV_32F);

}

/**
 * Main method that runs data frame processing to get feature vectors of all data in a given dataset,
 * thereafter classifying data according to classifiers as chosen according the user input.
 * Entering 'y' when prompted to classify will run the respective classification code, else the classifier is skipped.
 * A logfile is written each time the program is run, and relevant data for dataset processing and classification is recorded.
 * @param argc number of command line arguments
 * @param argv actual command line arguments: direct path to the dataset consisting of data sorted by participants should 
 * be added here, as the first command line argument of the executable program
*/
int main(int argc, char** argv)
{

	//set current time for logfile 
	time_t rawtime;
	struct tm * timeinfo;
	char buffer[80];
	time(&rawtime);
	timeinfo = localtime(&rawtime);
	strftime(buffer, 80, "%d%m%y %H%M%S", timeinfo);
	puts(buffer);
	std::string datetimestr = buffer;

	//open logfile
	std::ofstream logfile;
	logfile.open("KinectSASLClassification " + datetimestr);


	/*                                            */
	/* DATA PROCESSING / FEATURE EXTRACTION STAGE */
	/*                                            */

	// set for true random shuffling  throughout the program
	srand(time(0));

	// set path to frrst given command line argument, to obtain participant folders
	string rootPath = argv[1];
	vector<string> participantDirs, testParticipants;
	path root(rootPath);
	directory_iterator it_end;
	// iterate through participants
	for (directory_iterator it(root); it != it_end; ++it)
	{
		// check if participant folder has 'Kinect' subfolder, and add to participantDirs if it exists
		string path = it->path().string() + "\\Kinect";
		if (is_directory(path))
		{
			participantDirs.push_back(path);
		}
	}
	random_shuffle(participantDirs.begin(), participantDirs.end());

	// Note all participant directories
	logfile << endl << "Participant directories found: " << endl;
	cout << "Participant directories found: " << endl;
	for (int i = 0; i < participantDirs.size(); ++i) {
		logfile << "    " << participantDirs[i] << endl;
		cout << "    " << participantDirs[i] << endl;
	}
	cout << endl;
	logfile << endl;

	cout << "Reading and processing entire dataset..." << std::endl;
	logfile << "Reading and processing entire dataset..." << endl;
	double start = (double)cv::getTickCount();

	// participantGestures contains one vector per participant,
	// where each vector contains all the gestures of that participant
	vector<vector<string>> participantGestures(participantDirs.size());
	for (int i = 0; i < participantDirs.size(); ++i) {
		getSubDirectoriesInDirectory(participantDirs[i], participantGestures[i]);
		random_shuffle(participantGestures[i].begin(), participantGestures[i].end());
	}

	// imageMetadata contains all images with associated classes
	vector<vector<ImageData*>> imageMetadata(participantGestures.size());
	set<string> classes;
	int validgestures = 0, invalidgestures = 0;
	for (int j = 0; j < imageMetadata.size(); ++j)
	{
		// read all gestures of given participant
		readImages(validgestures, invalidgestures, participantGestures[j].begin(), participantGestures[j].end(),
			[&](const std::string& classname, const cv::Mat& img) {

			// Append to the set of classes
			classes.insert(classname);

			ImageData* data = new ImageData;
			data->classname = classname;
			// reshape frame into single row
			Mat1b frame = img.reshape(1, 1);
			data->image = frame;
			// append imageData (gesture) to respective participant vector
			imageMetadata[j].push_back(data);
		});
	}
	cout << "Time elapsed in minutes: " << ((double)getTickCount() - start) / getTickFrequency() / 60.0 << endl << endl;
	logfile << "Time elapsed in minutes: " << ((double)getTickCount() - start) / getTickFrequency() / 60.0 << endl << endl;

	cout << "Number of valid gestures in entire set: " << validgestures << endl;
	logfile << "Number of valid gestures in entire set: " << validgestures << endl;
	cout << "Number of invalid gestures left unread: " << invalidgestures << endl << endl;
	logfile << "Number of invalid gestures left unread: " << invalidgestures << endl << endl;
	cout << "----------------------------------------" << endl << endl << endl;
	logfile << "----------------------------------------" << endl << endl << endl;

	// sound prompt for user input
	Beep(1400, 1000); 




	/*                      */	
	/* CLASSIFICATION STAGE */
	/*                      */

	cv::Mat trainSamples, trainLabels, trainLabelsMLP, testSamples;
	std::vector<int> testOutputExpected;

	string input;
	cout << "Classify using Aritifical Neural Network? (y/n): ";
	cin >> input;
	if (input == "y") {
		cout << endl;

		/* Multi-Layer Perceptron */
		/*------------------------*/
		float accuracySum = 0;
		float trainTimeSum = 0;
		float predictionTimeSum = 0;
		float participantAccuracy = 0;
		float avgAccuracy = 0;
		float avgTrainTime = 0;
		float avgPredictionTime = 0;

		cout << "Starting ANN_MLP cross-validation testing..." << endl << endl;
		logfile << "Starting ANN_MLP cross-validation testing..." << endl << endl;

		for (int participantNumber = 0; participantNumber < imageMetadata.size(); ++participantNumber)
		{

			cout << "[Testing on data directory: " << participantDirs[participantNumber] << "]" << endl << endl;
			logfile << "[Testing on data directory: " << participantDirs[participantNumber] << "]" << endl << endl;
			getTrainAndTestDataMLP(imageMetadata, participantNumber, trainSamples, trainLabelsMLP, testSamples, testOutputExpected, classes);

			int networkInputSize = trainSamples.cols;
			int networkOutputSize = trainLabelsMLP.cols;
			int middleLayerSize = (int)(networkInputSize*(2 / 3.0) + networkOutputSize);
			// int middleLayerSize = (int)((networkInputSize + networkOutputSize)/2.0);
			vector<int> layerSizes = { networkInputSize, middleLayerSize, networkOutputSize };

			cout << "Training neural network with layer sizes: " << layerSizes[0] << " -> " << layerSizes[1] << " -> " << layerSizes[2] << endl;
			logfile << "Training neural network with layer sizes: " << layerSizes[0] << " -> " << layerSizes[1] << " -> " << layerSizes[2] << endl;
			start = getTickCount();

			//train mlp with training data
			Ptr<cv::ml::ANN_MLP> mlp = getTrainedNeuralNetwork(trainSamples, trainLabelsMLP, layerSizes);
			float trainTime = ((double)getTickCount() - start) / getTickFrequency() / 60.0;
			trainTimeSum += trainTime;
			cout << "Time elapsed in minutes: " << trainTime << endl << endl;
			logfile << "Time elapsed in minutes: " << trainTime << endl << endl;

			cout << "Predicting on test set..." << endl;
			logfile << "Predicting on test set..." << endl;
			start = cv::getTickCount();

			//feed test data into mlp to predict
			vector<vector<int>> mlpConfusionMatrix = getMLPConfusionMatrix(mlp, testSamples, testOutputExpected);
			float predictionTime = ((double)getTickCount() - start) / getTickFrequency() / 60.0;
			predictionTimeSum += predictionTime;
			cout << "Time elapsed in minutes: " << predictionTime << endl << endl;
			logfile << "Time elapsed in minutes: " << predictionTime << endl << endl;

			cout << "Confusion matrix - MLP: " << endl;
			logfile << "Confusion matrix - MLP: " << endl;
			cout << getConfusionMatrixString(mlpConfusionMatrix, classes) << endl << endl;
			logfile << getConfusionMatrixString(mlpConfusionMatrix, classes) << endl << endl;

			participantAccuracy = getAccuracy(mlpConfusionMatrix) * 100;
			accuracySum += participantAccuracy;
			cout << "Classifier accuracy rate - MLP: " << participantAccuracy << "%" << endl;
			logfile << "Classifier accuracy rate - MLP: " << participantAccuracy << "%" << endl;

			cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl << endl << endl;
			logfile << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl << endl << endl;

			//clear memory
			mlpConfusionMatrix.clear();
			mlp->clear();

		}

		avgAccuracy = accuracySum / (float)participantDirs.size();
		avgTrainTime = trainTimeSum / (float)participantDirs.size();
		avgPredictionTime = predictionTimeSum / (float)participantDirs.size();

		cout << "Average accuracy rate for MLP: " << avgAccuracy << endl << endl;
		logfile << "Average accuracy rate for MLP: " << avgAccuracy << endl << endl;

		cout << "Average training time for MLP, in minutes: " << avgTrainTime << endl << endl;
		logfile << "Average training time for MLP, in minutes: " << avgTrainTime << endl << endl;

		cout << "Average prediction time for MLP, in minutes: " << avgPredictionTime << endl << endl;
		logfile << "Average prediction time for MLP, in minutes : " << avgPredictionTime << endl << endl;

		cout << "----------------------------------------" << endl << endl;
		logfile << "----------------------------------------" << endl << endl;

	}
	/////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////


	input = "";
	cout << "Classify using k-Nearest Neighbour algorithm? (y/n): ";
	cin >> input;
	if (input == "y") {
		cout << endl;

		/* K-Nearest Neighbour */
		/*---------------------*/

		std::cout << "Starting kNN cross-validation search for best k-value (selecting between 1 and 25)..." << std::endl << endl;
		logfile << "Starting kNN cross-validation search for best k-value (selecting between 1 and 25)..." << std::endl << endl;
		start = getTickCount();

		float bestAccuracy = 0;	
		int bestKVal = 0;
		vector<float> kAccuracies;
		vector<float> predictionTimes;
		vector<float> trainingTimes;

		// iterate through k values
		for (int k = 1; k <= 25; ++k) {

			cout << "KNN with k = " << k << endl << endl;
			logfile << "KNN with k = " << k << endl << endl;

			float trainTimeSum = 0;
			float predictionTimeSum = 0;
			float avgTrainTime = 0;
			float avgPredictionTime = 0;

			vector<vector<int>> totalConfusionMatrix(26, std::vector<int>(26, 0));

			float accuracySum = 0;
			float participantAccuracy = 0;
			float kAccuracy = 0;

			// iterate through test participants (for cross-validation)
			for (int participantNumber = 0; participantNumber < imageMetadata.size(); ++participantNumber)
			{
				cout << "[Testing on data directory: " << participantDirs[participantNumber] << "]" << endl << endl;
				logfile << "[Testing on data directory: " << participantDirs[participantNumber] << "]" << endl << endl;
				getTrainAndTestData(imageMetadata, participantNumber, trainSamples, trainLabels, testSamples, testOutputExpected, classes);

				// setup and train knn
				start = getTickCount();
				cv::Ptr<cv::ml::KNearest> knn = getTrainedKNN(trainSamples, trainLabels, k);
				float trainTime = ((double)getTickCount() - start) / getTickFrequency() / 60.0;
				trainTimeSum += trainTime;

				// predict on trained knn with test set
				start = getTickCount();
				std::vector<std::vector<int>> knnConfusionMatrix = getKNNConfusionMatrix(knn, testSamples, testOutputExpected);
				float predictionTime = ((double)getTickCount() - start) / getTickFrequency() / 60.0;
				predictionTimeSum += predictionTime;

				// add confusion matrix for single test to cumulative confusion matrix for k-value
				addMatrix(totalConfusionMatrix, knnConfusionMatrix);

				// print confusion matrix
				cout << "Confusion matrix - KNN (k=" << k << "):" << endl;
				logfile << "Confusion matrix - KNN (k=" << k << "):" << endl;
				cout << getConfusionMatrixString(knnConfusionMatrix, classes) << endl;
				logfile << getConfusionMatrixString(knnConfusionMatrix, classes) << endl;

				//get accuracy for specific participant test
				participantAccuracy = getAccuracy(knnConfusionMatrix) * 100;
				accuracySum += participantAccuracy;
				cout << "Classifier accuracy rate - KNN (k=" << k << "): " << participantAccuracy << "%" << endl << endl;
				logfile << "Classifier accuracy rate - KNN (k=" << k << "): " << participantAccuracy << "%" << endl << endl;

				//clear memory
				knn->clear();
				knnConfusionMatrix.clear();

			}

			//training time
			avgTrainTime = trainTimeSum / (float)participantDirs.size();
			trainingTimes.push_back(avgTrainTime);
			cout << "Average training time, in minutes, for k = " << k << ": " << avgTrainTime << endl << endl;
			logfile << "Average training time, in minutes, for k = " << k << ": " << avgTrainTime << endl << endl;
			
			//prediction time
			avgPredictionTime = predictionTimeSum / (float)participantDirs.size();
			predictionTimes.push_back(avgPredictionTime);
			cout << "Average prediction time, in minutes, for k = " << k << ": " << avgPredictionTime << endl << endl;
			logfile << "Average prediciton time, in minutes, for k = " << k << ": " << avgPredictionTime << endl << endl;

			//accuracy for k value
			kAccuracy = accuracySum / (float)participantDirs.size();
			kAccuracies.push_back(kAccuracy);
			cout << "Average accuracy rate for k = " << k << ": " << kAccuracy << endl << endl;
			logfile << "Average accuracy rate for k = " << k << ": " << kAccuracy << endl << endl;

			//confusion matrix 
			cout << "Total confusion matrix for k = " << k << ": " << endl;
			logfile << "Total confusion matrix for k = " << k << ": " << endl;
			cout << getConfusionMatrixString(totalConfusionMatrix, classes) << endl << endl;
			logfile << getConfusionMatrixString(totalConfusionMatrix, classes) << endl << endl;

			//record best k value and respective accuracy
			if (kAccuracy > bestAccuracy)
			{
				bestAccuracy = kAccuracy;
				bestKVal = k;
			}

			totalConfusionMatrix.clear();

			cout << "----------------------------------------" << endl << endl;
			logfile << "----------------------------------------" << endl << endl;

		}

		cout << "========================================" << endl << endl;
		logfile << "========================================" << endl << endl;

		cout << "Summary of k-values and cross-validation accuracies, training times and prediction times: " << endl;
		logfile << "Summary of k-values and cross-validation accuracies, training times and prediction times: " << endl;

		for (int i = 1; i <= kAccuracies.size(); ++i) {
			cout << "   k = " << i << ": " << kAccuracies[i - 1]  << ", " << trainingTimes[i-1] << ", " << predictionTimes[i-1] << endl;
			logfile << "   k = " << i << ": " << kAccuracies[i - 1] << ", " << trainingTimes[i - 1] << ", " << predictionTimes[i - 1] << endl;
		}
		cout << endl;
		logfile << endl;

		cout << "Best accuracy after cross-validation: " << bestAccuracy << "% with k = " << bestKVal << endl;
		logfile << "Best accuracy after cross-validation: " << bestAccuracy << "% with k = " << bestKVal << endl;


	}
	/////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////


	input = "";
	cout << "Classify using Support Vector Machine with Linear Kernel? (y/n): ";
	cin >> input;
	if (input == "y") {
		cout << endl;

		/* Support Vector Machine on Linear Kernel */
		/*-----------------------------------------*/

		std::cout << "Starting SVM cross-validation search on Linear Kernel (with varying C values)..." << std::endl << endl;		
		logfile << "Starting SVM cross-validation search on Linear Kernel (with varying C values)..." << std::endl << endl;
		start = cv::getTickCount();

		float bestAccuracy = 0;
		int bestC = 0;
		vector<float> degreeAccuracies;
		vector<float> predictionTimes;
		vector<float> trainingTimes;

		// select values of C
		vector<double> cValues = { 0.5, 10, 100, 1000, 1000, 100000, 10000000 };

		for (int cIndex = 0; cIndex < cValues.size(); ++cIndex) {

			cout << "Linear Kernel with C = " << cValues[cIndex] << endl;
			logfile << "Linear Kernel with C = " << cValues[cIndex] << endl;
			float accuracySum = 0;
			float participantAccuracy = 0;
			float cAccuracy = 0;

			vector<vector<int>> totalConfusionMatrix(26, std::vector<int>(26, 0));

			float trainTimeSum = 0;
			float predictionTimeSum = 0;
			float avgTrainTime = 0;
			float avgPredictionTime = 0;

			// iterate through test participants (for cross-validation)
			for (int participantNumber = 0; participantNumber < imageMetadata.size(); ++participantNumber)
			{

				cout << "[Testing on data directory: " << participantDirs[participantNumber] << "]" << endl << endl;
				logfile << "[Testing on data directory: " << participantDirs[participantNumber] << "]" << endl << endl;
				getTrainAndTestData(imageMetadata, participantNumber, trainSamples, trainLabels, testSamples, testOutputExpected, classes);

				// setup and train svm
				start = getTickCount();
				cv::Ptr<cv::ml::SVM> svm = getTrainedLinearSVM(trainSamples, trainLabels, cValues[cIndex]);
				float trainTime = ((double)getTickCount() - start) / getTickFrequency() / 60.0;
				trainTimeSum += trainTime;

				// test svm on test dataset
				start = getTickCount();
				std::vector<std::vector<int>> svmConfusionMatrix = getSVMConfusionMatrix(svm, testSamples, testOutputExpected);
				float predictionTime = ((double)getTickCount() - start) / getTickFrequency() / 60.0;
				predictionTimeSum += predictionTime;

				// add confusion matrix for single test to cumulative confusion matrix for C value
				addMatrix(totalConfusionMatrix, svmConfusionMatrix);

				// print confusion matrix
				cout << "Confusion matrix - SVM (C=" << cValues[cIndex] << "): " << endl;
				logfile << "Confusion matrix - SVM (C=" << cValues[cIndex] << "): " << endl;
				cout << getConfusionMatrixString(svmConfusionMatrix, classes) << endl;
				logfile << getConfusionMatrixString(svmConfusionMatrix, classes) << endl;

				participantAccuracy = getAccuracy(svmConfusionMatrix) * 100;
				accuracySum += participantAccuracy;
				cout << "Classifier accuracy rate - SVM (C=" << cValues[cIndex] << "): " << getAccuracy(svmConfusionMatrix) * 100 << "%" << endl << endl;
				logfile << "Classifier accuracy rate - SVM (C=" << cValues[cIndex] << "): " << getAccuracy(svmConfusionMatrix) * 100 << "%" << endl << endl;

				// clear memory
				svm->clear();
				svmConfusionMatrix.clear();

			}

			//training time
			avgTrainTime = trainTimeSum / (float)participantDirs.size();
			trainingTimes.push_back(avgTrainTime);
			cout << "Average training time, in minutes, for C = " << cValues[cIndex] << ": " << avgTrainTime << endl << endl;
			logfile << "Average training time, in minutes, for C = " << cValues[cIndex] << ": " << avgTrainTime << endl << endl;

			//prediction time
			avgPredictionTime = predictionTimeSum / (float)participantDirs.size();
			predictionTimes.push_back(avgPredictionTime);
			cout << "Average prediction time, in minutes, for C = " << cValues[cIndex] << ": " << avgPredictionTime << endl << endl;
			logfile << "Average prediciton time, in minutes, for C = " << cValues[cIndex] << ": " << avgPredictionTime << endl << endl;

			//accuracy for C value
			cAccuracy = accuracySum / (float)participantDirs.size();
			degreeAccuracies.push_back(cAccuracy);
			cout << "Average accuracy rate for C = " << cValues[cIndex] << ": " << cAccuracy << "%" << endl << endl;
			logfile << "Average accuracy rate for C = " << cValues[cIndex] << ": " << cAccuracy << "%" << endl << endl;

			//record best C and respective accuracy
			if (cAccuracy > bestAccuracy)
			{
				bestAccuracy = cAccuracy;
				bestC = cValues[cIndex];
			}

			cout << "Total confusion matrix for C = " << cValues[cIndex] << ": " << endl;
			logfile << "Total confusion matrix for C = " << cValues[cIndex] << ": " << endl;
			cout << getConfusionMatrixString(totalConfusionMatrix, classes) << endl << endl;
			logfile << getConfusionMatrixString(totalConfusionMatrix, classes) << endl << endl;

			totalConfusionMatrix.clear();

			cout << "----------------------------------------" << endl << endl;
			logfile << "----------------------------------------" << endl << endl;

		}

		cout << "========================================" << endl << endl;
		logfile << "========================================" << endl << endl;

		cout << "Summary of C-values and cross-validation accuracies, training times and prediction times: " << endl;
		logfile << "Summary of C-values and cross-validation accuracies, training times and prediction times: " << endl;

		for (int i = 0; i < degreeAccuracies.size(); ++i) {
			cout << "   C = " << cValues[i] << ": " << degreeAccuracies[i] << ", " << trainingTimes[i] << ", " << predictionTimes[i] << endl;
			logfile << "   C = " << cValues[i] << ": " << degreeAccuracies[i] << ", " << trainingTimes[i] << ", " << predictionTimes[i] << endl;
		}
		cout << endl;
		logfile << endl;

		cout << "Best accuracy after cross-validation: " << bestAccuracy << " with C = " << bestC << endl;
		logfile << "Best accuracy after cross-validation: " << bestAccuracy << " with C = " << bestC << endl;

	}
	/////////////////////////////////////////////////////////////////////////



	input = "";
	cout << "Classify using Support Vector Machine with POLY Kernel? (y/n): ";
	cin >> input;
	if (input == "y") {
		cout << endl;

		/* Support Vector Machine on Polynomial Kernel */
		/*---------------------------------------------*/

		std::cout << "Starting SVM cross-validation search on Polynomial Kernel (degrees between 2 and 7)..." << std::endl << endl;
		logfile << "Starting SVM cross-validation search on Polynomial Kernel (degrees between 2 and 7)..." << std::endl << endl;
		start = cv::getTickCount();

		float bestAccuracy = 0;
		int bestDegree = 0;
		vector<float> degreeAccuracies;
		vector<float> predictionTimes;
		vector<float> trainingTimes;

		//iterate through selected degrees
		for (int degree = 2; degree <= 7; ++degree) {

			cout << "Polynomial Kernel with degree: " << degree << endl;
			logfile << "Polynomial Kernel with degree: " << degree << endl;
			float accuracySum = 0;
			float participantAccuracy = 0;
			float degreeAccuracy = 0;

			vector<vector<int>> totalConfusionMatrix(26, std::vector<int>(26, 0));

			float trainTimeSum = 0;
			float predictionTimeSum = 0;
			float avgTrainTime = 0;
			float avgPredictionTime = 0;
			// iterate through test participants (for cross-validation)
			for (int participantNumber = 0; participantNumber < imageMetadata.size(); ++participantNumber)
			{

				cout << "[Testing on data directory: " << participantDirs[participantNumber] << "]" << endl << endl;
				logfile << "[Testing on data directory: " << participantDirs[participantNumber] << "]" << endl << endl;
				getTrainAndTestData(imageMetadata, participantNumber, trainSamples, trainLabels, testSamples, testOutputExpected, classes);

				// setup and train svm
				start = getTickCount();
				cv::Ptr<cv::ml::SVM> svm = getTrainedPolySVM(trainSamples, trainLabels, degree, 1);
				float trainTime = ((double)getTickCount() - start) / getTickFrequency() / 60.0;
				trainTimeSum += trainTime;

				// predict on trained svm with test dataset
				start = getTickCount();
				std::vector<std::vector<int>> svmConfusionMatrix = getSVMConfusionMatrix(svm, testSamples, testOutputExpected);
				float predictionTime = ((double)getTickCount() - start) / getTickFrequency() / 60.0;
				predictionTimeSum += predictionTime;

				// add confusion matrix for single test to cumulative confusion matrix for C value
				addMatrix(totalConfusionMatrix, svmConfusionMatrix);

				// print confusion matrix
				cout << "Confusion matrix - SVM (degree=" << degree << "): " << endl;
				logfile << "Confusion matrix - SVM (degree=" << degree << "): " << endl;
				cout << getConfusionMatrixString(svmConfusionMatrix, classes) << endl;
				logfile << getConfusionMatrixString(svmConfusionMatrix, classes) << endl;

				//accuracy for C value
				participantAccuracy = getAccuracy(svmConfusionMatrix) * 100;
				accuracySum += participantAccuracy;
				cout << "Classifier accuracy rate - SVM (degree=" << degree << "): " << getAccuracy(svmConfusionMatrix) * 100 << "%" << endl << endl;
				logfile << "Classifier accuracy rate - SVM (degree=" << degree << "): " << getAccuracy(svmConfusionMatrix) * 100 << "%" << endl << endl;

				// clear memory
				svm->clear();
				svmConfusionMatrix.clear();

			}

			//training time
			avgTrainTime = trainTimeSum / (float)participantDirs.size();
			trainingTimes.push_back(avgTrainTime);
			cout << "Average training time, in minutes, for degree = " << degree << ": " << avgTrainTime << endl << endl;
			logfile << "Average training time, in minutes, for degree = " << degree << ": " << avgTrainTime << endl << endl;

			//prediction time
			avgPredictionTime = predictionTimeSum / (float)participantDirs.size();
			predictionTimes.push_back(avgPredictionTime);
			cout << "Average prediction time, in minutes, for degree = " << degree << ": " << avgPredictionTime << endl << endl;
			logfile << "Average prediciton time, in minutes, for degree = " << degree << ": " << avgPredictionTime << endl << endl;

			//accuracy for degree
			degreeAccuracy = accuracySum / (float)participantDirs.size();
			degreeAccuracies.push_back(degreeAccuracy);
			cout << "Average accuracy rate for degree = " << degree << ": " << degreeAccuracy << "%" << endl << endl;
			logfile << "Average accuracy rate for degree = " << degree << ": " << degreeAccuracy << "%" << endl << endl;

			//record best degree and respective accuracy
			if (degreeAccuracy > bestAccuracy)
			{
				bestAccuracy = degreeAccuracy;
				bestDegree = degree;
			}

			cout << "Total confusion matrix for degree = " << degree << ": " << endl;
			logfile << "Total confusion matrix for degree = " << degree << ": " << endl;
			cout << getConfusionMatrixString(totalConfusionMatrix, classes) << endl << endl;
			logfile << getConfusionMatrixString(totalConfusionMatrix, classes) << endl << endl;

			totalConfusionMatrix.clear();

			cout << "----------------------------------------" << endl << endl;
			logfile << "----------------------------------------" << endl << endl;

		}

		cout << "========================================" << endl << endl;
		logfile << "========================================" << endl << endl;

		cout << "Summary of degrees and cross-validation accuracies, training times and prediction times: " << endl;
		logfile << "Summary of degrees and cross-validation accuracies, training times and prediction times: " << endl;

		for (int i = 1; i <= degreeAccuracies.size(); ++i) {
			cout << "   k = " << i << ": " << degreeAccuracies[i - 1] << ", " << trainingTimes[i - 1] << ", " << predictionTimes[i - 1] << endl;
			logfile << "   k = " << i << ": " << degreeAccuracies[i - 1] << ", " << trainingTimes[i - 1] << ", " << predictionTimes[i - 1] << endl;
		}
		cout << endl;
		logfile << endl;

		cout << "Best accuracy after cross-validation: " << bestAccuracy << "% with degree = " << bestDegree << endl;
		logfile << "Best accuracy after cross-validation: " << bestAccuracy << "% with degree = " << bestDegree << endl;


	}
	/////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////


	input = "";
	cout << "Classify using Support Vector Machine with RBF Kernel (AutoTrain)? (y/n): ";
	cin >> input;
	if (input == "y") {
		cout << endl;

		std::cout << "Starting AutoTrain on RBF-Kernel SVM, searching for optimal parameters..." << std::endl << endl;
		logfile << "Starting AutoTrain on RBF-Kernel SVM, searching for optimal parameters..." << std::endl << endl;

		/* Support Vector Machine on RBF Kernel */
		/*---------------------------------------------*/

		cv::Mat trainSamples, trainLabels, testSamples;
		std::vector<int> testOutputExpected;

		// take one random participant's data for testing
		cout << "[Testing on data directory: " << participantDirs[0] << "]" << endl << endl;
		logfile << "[Testing on data directory: " << participantDirs[0] << "]" << endl << endl;
		getTrainAndTestData(imageMetadata, 0, trainSamples, trainLabels, testSamples, testOutputExpected, classes);

		// setup and train svm
		start = cv::getTickCount();
		cv::Ptr<cv::ml::SVM> svm = getAutoTrainedRBFSVM(trainSamples, trainLabels);
		cout << "Time elapsed (for auto train on RBF Kernel) in minutes: " << ((double)getTickCount() - start) / getTickFrequency() / 60.0 << endl << endl;
		logfile << "Time elapsed (for auto train on RBF Kernel) in minutes: " << ((double)getTickCount() - start) / getTickFrequency() / 60.0 << endl << endl;

		cout << "*****" << endl << endl;
		logfile << "*****" << endl << endl;

		// print confusion matrix
		std::vector<std::vector<int>> svmConfusionMatrix = getSVMConfusionMatrix(svm, testSamples, testOutputExpected);
		cout << "Confusion matrix - SVM: " << endl;
		logfile << "Confusion matrix - SVM: " << endl;
		cout << getConfusionMatrixString(svmConfusionMatrix, classes) << endl;
		logfile << getConfusionMatrixString(svmConfusionMatrix, classes) << endl;

		cout << "Classifier accuracy rate - SVM: " << getAccuracy(svmConfusionMatrix) * 100 << "%" << endl << endl;
		logfile << "Classifier accuracy rate - SVM: " << getAccuracy(svmConfusionMatrix) * 100 << "%" << endl << endl;

		cout << "Optimal value for parameter C = " << svm->getC() << endl << endl;
		logfile << "Optimal value for parameter C = " << svm->getC() << endl << endl;
		cout << "Optimal value for paramter gamma = " << svm->getGamma() << endl << endl;
		logfile << "Optimal value for paramter gamma = " << svm->getGamma() << endl << endl;

		cout << "========================================" << endl << endl;
		logfile << "========================================" << endl << endl;

		// clear memory
		svm->clear();
		svmConfusionMatrix.clear();

	}
	/////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////


	input = "";
	cout << "Classify using Voting Classifier? (y/n): ";
	cin >> input;
	if (input == "y") 
	{

		float accuracySum = 0;
		float participantAccuracy = 0;

		float trainTimeSum = 0;
		float predictionTimeSum = 0;

		for (int participantNumber = 0; participantNumber < imageMetadata.size(); ++participantNumber)
		{
			// take one random participant's data for testing
			cout << "[Testing on data directory: " << participantDirs[participantNumber] << "]" << endl << endl;
			logfile << "[Testing on data directory: " << participantDirs[participantNumber] << "]" << endl << endl;
			getTrainAndTestData(imageMetadata, participantNumber, trainSamples, trainLabels, testSamples, testOutputExpected, classes);

			//train linear kernel svm
			double trainStart = getTickCount();
			cout << "Training SVM on Linear Kernel..." << endl;
			start = cv::getTickCount();
			Ptr<ml::SVM> svmLin = getTrainedLinearSVM(trainSamples, trainLabels, 1);
			cout << "---> Completed Training of Linear Kernel SVM in " << ((double)getTickCount() - start) / getTickFrequency() / 60.0 << " minutes." << endl;
			logfile << "---> Completed Training of Linear Kernel SVM in " << ((double)getTickCount() - start) / getTickFrequency() / 60.0 << " minutes." << endl;

			//train polynomial kernel svm
			cout << "Training SVM on Polynomial Kernel with degree 3..." << endl;
			start = cv::getTickCount();
			Ptr<ml::SVM> svmPoly = getTrainedPolySVM(trainSamples, trainLabels, 3, 1);
			cout << "---> Completed Training of Polynomial Kernel SVM in " << ((double)getTickCount() - start) / getTickFrequency() / 60.0 << " minutes." << endl;
			logfile << "---> Completed Training of Polynomial Kernel SVM in " << ((double)getTickCount() - start) / getTickFrequency() / 60.0 << " minutes." << endl;

			//train knn
			cout << "Training KNN with k = 10..." << endl;
			start = cv::getTickCount();
			cv::Ptr<cv::ml::KNearest> knn = getTrainedKNN(trainSamples, trainLabels, 10);
			cout << "---> Completed Training of KNN in " << ((double)getTickCount() - start) / getTickFrequency() / 60.0 << " minutes." << endl << endl;
			logfile << "---> Completed Training of KNN in " << ((double)getTickCount() - start) / getTickFrequency() / 60.0 << " minutes." << endl << endl;
			trainTimeSum += ((double)getTickCount() - trainStart) / getTickFrequency() / 60.0;

			//predict using voting classifier
			cout << "Predicting using hard voting between 3 classifiers..." << endl;
			logfile << "Predicting using hard voting between 3 classifiers..." << endl;
			start = cv::getTickCount();
			std::vector<std::vector<int>> votingConfusionMatrix = getVotingClassifierConfusionMatrix(svmLin, svmPoly, knn, testSamples, testOutputExpected, true);
			predictionTimeSum += ((double)getTickCount() - start) / getTickFrequency() / 60.0;
			cout << "Time elapsed (for prediction on voting classifier) in minutes: " << ((double)getTickCount() - start) / getTickFrequency() / 60.0 << endl << endl;
			logfile << "Time elapsed (for prediction on voting classifier) in minutes: " << ((double)getTickCount() - start) / getTickFrequency() / 60.0 << endl << endl;
			cout << "*****" << endl << endl;
			logfile << "*****" << endl << endl;
			// print confusion matrix
			cout << "Confusion matrix - Voting Classifier: " << endl;
			logfile << "Confusion matrix - Voting Classifier: " << endl;
			cout << getConfusionMatrixString(votingConfusionMatrix, classes) << endl;
			logfile << getConfusionMatrixString(votingConfusionMatrix, classes) << endl;

			//accuracy for participant test
			participantAccuracy = getAccuracy(votingConfusionMatrix) * 100;
			accuracySum += participantAccuracy;
			cout << "Classifier accuracy rate - Voting Classifier 2: " << participantAccuracy << "%" << endl << endl;
			logfile << "Classifier accuracy rate - Voting Classifier 2: " << participantAccuracy << "%" << endl << endl;

			cout << "========================================" << endl << endl;
			logfile << "========================================" << endl << endl;
		}

		//training time
		float avgTrainTime = trainTimeSum / (float)participantDirs.size();
		cout << "Average training time, in minutes: " << avgTrainTime << endl << endl;
		logfile << "Average training time, in minutes: " << avgTrainTime << endl << endl;

		//prediction time
		float avgPredictionTime = predictionTimeSum / (float)participantDirs.size();
		cout << "Average prediction time, in minutes: " << avgPredictionTime << endl << endl;
		logfile << "Average prediciton time, in minutes: " << avgPredictionTime << endl << endl;

		//final cross-validation accuracy 
		float averageAccuracy = accuracySum / (float)participantDirs.size();
		cout << "Average accuracy rate for Voting Classifier, after cross validation: " << averageAccuracy << "%" << endl << endl;
		logfile << "Average accuracy rate for Voting Classifier, after cross-validation: " << averageAccuracy << "%" << endl << endl;

	}


	// Clear memory now 
	trainSamples.release();
	trainLabelsMLP.release();
	trainLabels.release();
	testSamples.release();
	testOutputExpected.clear();
	logfile.close();

	// de-allocate memory for imageMetadata
	for (int i = 0; i < imageMetadata.size(); ++i)
	{
		for (auto it = imageMetadata[i].begin(); it != imageMetadata[i].end(); it++)
			delete *it;
	}
	imageMetadata.clear();

	Beep(1568, 1000); //signify end of program's run
	waitKey(0);

    return 0;

}